<form method="get" id="s-form" action="<?php echo home_url(); ?>/">
	<input type="text" name="s" class="search-bar" id="s-input-text" value="" placeholder="<?php _e('Type and hit enter...','avalance') ?>" />
    <i class="fa fa-search"></i>
</form>